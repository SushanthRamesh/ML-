from sys import argv



print ("The script is called:")
print ("Your first variable is:")
print ("Your second variable is:") 
print ("Your third variable is:")